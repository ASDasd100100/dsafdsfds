/* ============================================================
   NABD — Interactions & Motion
   ============================================================ */
(function () {
  "use strict";

  var prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var isFinePointer = window.matchMedia("(hover: hover) and (pointer: fine)").matches;

  /* ---------- Year in footer ---------- */
  var yearEl = document.getElementById("year");
  if (yearEl) yearEl.textContent = String(new Date().getFullYear());

  /* ---------- Image fade-in on load (no flash / no layout shift) ---------- */
  document.querySelectorAll("img").forEach(function (img) {
    if (img.complete && img.naturalWidth > 0) {
      img.classList.add("loaded");
    } else {
      img.addEventListener("load", function () { img.classList.add("loaded"); }, { once: true });
      img.addEventListener("error", function () { img.classList.add("loaded"); }, { once: true });
    }
  });

  /* ---------- Reveal on scroll (Fade Up + Stagger via data-delay) ---------- */
  var revealEls = document.querySelectorAll(".reveal");
  revealEls.forEach(function (el) {
    var d = el.getAttribute("data-delay");
    if (d) el.style.setProperty("--reveal-delay", d + "ms");
  });

  if ("IntersectionObserver" in window && !prefersReducedMotion) {
    var revealObserver = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add("in-view");
          revealObserver.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12, rootMargin: "0px 0px -40px 0px" });

    revealEls.forEach(function (el) { revealObserver.observe(el); });
  } else {
    revealEls.forEach(function (el) { el.classList.add("in-view"); });
  }

  /* ---------- Navbar: sticky state + active link ---------- */
  var navbar = document.getElementById("navbar");
  var navLinks = document.querySelectorAll(".nav__link");
  var sections = Array.prototype.map.call(
    document.querySelectorAll("main section[id]"),
    function (s) { return s; }
  );

  function onScroll() {
    var y = window.scrollY || window.pageYOffset;
    if (navbar) navbar.classList.toggle("scrolled", y > 30);

    // Active section highlight
    var currentId = "home";
    sections.forEach(function (sec) {
      if (sec.offsetTop - 140 <= y) currentId = sec.id;
    });
    navLinks.forEach(function (link) {
      var target = (link.getAttribute("href") || "").replace("#", "");
      link.classList.toggle("active", target === currentId);
    });
  }

  var ticking = false;
  window.addEventListener("scroll", function () {
    if (!ticking) {
      window.requestAnimationFrame(function () { onScroll(); ticking = false; });
      ticking = true;
    }
  }, { passive: true });
  onScroll();

  /* ---------- Mobile menu ---------- */
  var navToggle = document.getElementById("navToggle");
  var mobileMenu = document.getElementById("mobileMenu");

  function setMenu(open) {
    if (!mobileMenu || !navToggle) return;
    mobileMenu.classList.toggle("open", open);
    navToggle.classList.toggle("open", open);
    navToggle.setAttribute("aria-expanded", open ? "true" : "false");
    navToggle.setAttribute("aria-label", open ? "إغلاق القائمة" : "فتح القائمة");
    mobileMenu.setAttribute("aria-hidden", open ? "false" : "true");
    document.body.style.overflow = open ? "hidden" : "";
  }

  if (navToggle) {
    navToggle.addEventListener("click", function () {
      setMenu(!mobileMenu.classList.contains("open"));
    });
  }
  if (mobileMenu) {
    mobileMenu.addEventListener("click", function (e) {
      if (e.target === mobileMenu) setMenu(false);
      if (e.target.closest(".mobile-menu__link")) setMenu(false);
    });
  }
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") setMenu(false);
  });

  /* ---------- Parallax (light) ---------- */
  var parallaxEls = document.querySelectorAll(".parallax");
  if (parallaxEls.length && !prefersReducedMotion && isFinePointer) {
    var pTicking = false;
    window.addEventListener("scroll", function () {
      if (pTicking) return;
      window.requestAnimationFrame(function () {
        var y = window.scrollY || window.pageYOffset;
        parallaxEls.forEach(function (el) {
          var speed = parseFloat(el.getAttribute("data-speed")) || 0.05;
          var rect = el.getBoundingClientRect();
          var center = rect.top + y + rect.height / 2;
          var offset = (y + window.innerHeight / 2 - center) * speed;
          el.style.transform = "translate3d(0," + offset.toFixed(2) + "px,0)";
        });
        pTicking = false;
      });
      pTicking = true;
    }, { passive: true });
  }

  /* ---------- Mouse follow glow ---------- */
  var glow = document.querySelector(".cursor-glow");
  if (glow && isFinePointer && !prefersReducedMotion) {
    document.body.classList.add("has-pointer");
    var gx = window.innerWidth / 2, gy = window.innerHeight / 2;
    var cx = gx, cy = gy, glowRaf = null;

    function renderGlow() {
      cx += (gx - cx) * 0.16;
      cy += (gy - cy) * 0.16;
      glow.style.transform = "translate3d(" + cx + "px," + cy + "px,0)";
      if (Math.abs(gx - cx) > 0.4 || Math.abs(gy - cy) > 0.4) {
        glowRaf = window.requestAnimationFrame(renderGlow);
      } else {
        glowRaf = null;
      }
    }

    window.addEventListener("mousemove", function (e) {
      gx = e.clientX;
      gy = e.clientY;
      glow.classList.add("is-visible");
      if (!glowRaf) glowRaf = window.requestAnimationFrame(renderGlow);
    }, { passive: true });

    document.addEventListener("mouseleave", function () {
      glow.classList.remove("is-visible");
    });
  }

  /* ---------- Magnetic buttons (desktop only) ---------- */
  if (isFinePointer && !prefersReducedMotion) {
    document.querySelectorAll(".magnetic").forEach(function (btn) {
      var rect = null;

      btn.addEventListener("mouseenter", function () { rect = btn.getBoundingClientRect(); });
      btn.addEventListener("mousemove", function (e) {
        if (!rect) rect = btn.getBoundingClientRect();
        var mx = e.clientX - rect.left - rect.width / 2;
        var my = e.clientY - rect.top - rect.height / 2;
        var pullX = Math.max(-8, Math.min(8, mx * 0.22));
        var pullY = Math.max(-6, Math.min(6, my * 0.28));
        btn.style.transform = "translate(" + pullX + "px," + pullY + "px)";
      });
      btn.addEventListener("mouseleave", function () {
        btn.style.transform = "";
        rect = null;
      });
    });
  }

  /* ---------- Contact form validation ---------- */
  var form = document.getElementById("contactForm");
  var statusEl = document.getElementById("formStatus");

  function setError(fieldId, message) {
    var input = document.getElementById(fieldId);
    if (!input) return;
    var wrap = input.closest(".form-field");
    var err = wrap ? wrap.querySelector(".field-error") : null;
    if (wrap) wrap.classList.toggle("invalid", !!message);
    if (err) err.textContent = message || "";
    input.setAttribute("aria-invalid", message ? "true" : "false");
  }

  function validateForm() {
    var ok = true;
    var name = document.getElementById("fName");
    var company = document.getElementById("fCompany");
    var phone = document.getElementById("fPhone");
    var email = document.getElementById("fEmail");
    var type = document.getElementById("fType");
    var message = document.getElementById("fMessage");

    if (name.value.trim().length < 2) {
      setError("fName", "يرجى إدخال الاسم.");
      ok = false;
    } else setError("fName", "");

    if (company.value.trim().length < 2) {
      setError("fCompany", "يرجى إدخال اسم الشركة أو الصيدلية.");
      ok = false;
    } else setError("fCompany", "");

    // Egyptian mobile or general phone
    var phonePattern = /^(\+?2)?01[0125][0-9]{8}$|^[0-9]{7,15}$/;
    var phoneValue = phone.value.replace(/[\s\-()]/g, "");
    if (!phonePattern.test(phoneValue)) {
      setError("fPhone", "يرجى إدخال رقم هاتف صحيح (مثال: 01025888895).");
      ok = false;
    } else setError("fPhone", "");

    if (email.value.trim() !== "" && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email.value.trim())) {
      setError("fEmail", "يرجى إدخال بريد إلكتروني صحيح أو ترك الحقل فارغًا.");
      ok = false;
    } else setError("fEmail", "");

    if (type.value === "") {
      setError("fType", "يرجى اختيار نوع الاستفسار.");
      ok = false;
    } else setError("fType", "");

    if (message.value.trim().length < 10) {
      setError("fMessage", "يرجى كتابة تفاصيل الرسالة (10 أحرف على الأقل).");
      ok = false;
    } else setError("fMessage", "");

    return ok;
  }

  if (form) {
    // Clear error while typing
    form.querySelectorAll("input, select, textarea").forEach(function (input) {
      input.addEventListener("input", function () {
        var wrap = input.closest(".form-field");
        if (wrap && wrap.classList.contains("invalid")) {
          wrap.classList.remove("invalid");
          input.removeAttribute("aria-invalid");
        }
      });
    });

    form.addEventListener("submit", function (e) {
      e.preventDefault();
      if (!statusEl) return;

      if (!validateForm()) {
        statusEl.className = "form-status error";
        statusEl.textContent = "يرجى مراجعة الحقول المطلوبة وإدخال بيانات صحيحة.";
        var firstInvalid = form.querySelector(".form-field.invalid input, .form-field.invalid select, .form-field.invalid textarea");
        if (firstInvalid) firstInvalid.focus();
        return;
      }

      // No backend is configured: build a mailto fallback instead of claiming a real send.
      var name = document.getElementById("fName").value.trim();
      var company = document.getElementById("fCompany").value.trim();
      var phone = document.getElementById("fPhone").value.trim();
      var email = document.getElementById("fEmail").value.trim();
      var type = document.getElementById("fType").value;
      var message = document.getElementById("fMessage").value.trim();

      var subject = "استفسار من الموقع — " + type + " — " + company;
      var body =
        "الاسم: " + name + "\n" +
        "الشركة / الصيدلية: " + company + "\n" +
        "رقم الهاتف: " + phone + "\n" +
        "البريد الإلكتروني: " + (email || "غير متوفر") + "\n" +
        "نوع الاستفسار: " + type + "\n\n" +
        "تفاصيل الرسالة:\n" + message + "\n";

      var mailtoUrl =
        "mailto:nabd.eg@outlook.com?subject=" + encodeURIComponent(subject) +
        "&body=" + encodeURIComponent(body);

      statusEl.className = "form-status success";
      statusEl.innerHTML =
        "تم التحقق من البيانات بنجاح. نموذج التواصل جاهز للتكامل مع خدمة إرسال فعلية، " +
        "ولكن لم يتم ربطه بخدمة إرسال آلي بعد. " +
        '<a href="' + mailtoUrl + '">اضغط هنا لفتح برنامج البريد وإرسال رسالتك الآن</a>.';

      // Open the mail client as a working fallback
      window.location.href = mailtoUrl;
    });
  }
})();
